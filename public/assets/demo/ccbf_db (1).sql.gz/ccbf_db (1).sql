-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 26, 2025 at 07:01 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ccbf_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `crop_protections`
--

CREATE TABLE `crop_protections` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `plot_id` bigint(20) UNSIGNED NOT NULL,
  `application_date` date NOT NULL,
  `fertilizer_id` bigint(20) UNSIGNED NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit` varchar(255) NOT NULL,
  `season` varchar(255) NOT NULL,
  `machinery_cost` decimal(10,2) DEFAULT NULL,
  `manpower_used` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fertilizer_applications`
--

CREATE TABLE `fertilizer_applications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `plot_id` bigint(20) UNSIGNED NOT NULL,
  `application_date` date NOT NULL,
  `fertilizer_id` bigint(20) UNSIGNED NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit` varchar(255) NOT NULL,
  `season` varchar(255) NOT NULL,
  `machinery_cost` decimal(10,2) DEFAULT NULL,
  `manpower_used` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `growth_monitorings`
--

CREATE TABLE `growth_monitorings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `plot_id` bigint(20) UNSIGNED NOT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `harvestings`
--

CREATE TABLE `harvestings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sample_number` varchar(255) NOT NULL,
  `plot_id` bigint(20) UNSIGNED NOT NULL,
  `moisture_level` decimal(5,2) NOT NULL,
  `machinery_cost` decimal(10,2) NOT NULL,
  `labor_cost` decimal(10,2) NOT NULL,
  `harvest_type` varchar(255) NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `irrigation_records`
--

CREATE TABLE `irrigation_records` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `plot_id` bigint(20) UNSIGNED NOT NULL,
  `irrigation_number` varchar(255) NOT NULL,
  `stage` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `irrigation_date` date NOT NULL,
  `days_after_sowing` int(11) NOT NULL,
  `manpower_count` int(11) NOT NULL,
  `time_duration` varchar(255) NOT NULL,
  `maintenance_notes` text DEFAULT NULL,
  `maintenance_manpower` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `land_preparations`
--

CREATE TABLE `land_preparations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `plot_id` bigint(20) UNSIGNED NOT NULL,
  `machine_id` bigint(20) UNSIGNED DEFAULT NULL,
  `leveling` varchar(255) DEFAULT NULL,
  `area_worked` decimal(10,2) NOT NULL,
  `pre_sowing_injection_date` date NOT NULL,
  `land_quality` varchar(255) NOT NULL,
  `manpower_count` int(11) NOT NULL,
  `time_duration` varchar(255) NOT NULL,
  `major_maintenance` text DEFAULT NULL,
  `maintenance_manpower` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `master_fertilizer`
--

CREATE TABLE `master_fertilizer` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sr_no` varchar(255) DEFAULT NULL,
  `fertilizer_name` varchar(255) NOT NULL,
  `purchase_date` date NOT NULL,
  `supplier_name` varchar(255) NOT NULL,
  `fertilizer_type` varchar(255) NOT NULL,
  `storage_location` varchar(255) NOT NULL,
  `cost_per_bag` decimal(10,2) NOT NULL,
  `brand_name` varchar(255) NOT NULL,
  `expiry_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `master_land`
--

CREATE TABLE `master_land` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `st_no` varchar(255) DEFAULT NULL,
  `plot_no` varchar(255) NOT NULL,
  `block` varchar(255) NOT NULL,
  `super_wiser_name` varchar(255) NOT NULL,
  `area_ha` decimal(10,2) NOT NULL,
  `soil_type` varchar(255) NOT NULL,
  `previous_crop` varchar(255) DEFAULT NULL,
  `current_crop` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `master_machine`
--

CREATE TABLE `master_machine` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `st_no` varchar(255) DEFAULT NULL,
  `machine_name` varchar(255) NOT NULL,
  `machine_type` varchar(255) NOT NULL,
  `brand_model_no` varchar(255) NOT NULL,
  `purchase_date` date NOT NULL,
  `document_path` varchar(255) DEFAULT NULL,
  `status` enum('active','maintenance','inactive') NOT NULL DEFAULT 'active',
  `image_path` varchar(255) DEFAULT NULL,
  `last_service_date` date DEFAULT NULL,
  `next_service_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `master_records`
--

CREATE TABLE `master_records` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type` enum('land','machine','seed','fertilizer') NOT NULL,
  `record_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `master_references`
--

CREATE TABLE `master_references` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `master_seed`
--

CREATE TABLE `master_seed` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `st_no` varchar(255) DEFAULT NULL,
  `seed_name` varchar(255) NOT NULL,
  `seed_type` varchar(255) NOT NULL,
  `seed_sub_type` varchar(255) DEFAULT NULL,
  `row` int(11) DEFAULT NULL,
  `unit` varchar(255) NOT NULL,
  `per_bag_cost` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2025_03_25_054655_create_master_land_table', 2),
(6, '2025_03_25_054753_create_master_machine_table', 2),
(7, '2025_03_25_054809_create_master_seed_table', 2),
(8, '2025_03_25_054828_create_master_fertilizer_table', 2),
(9, '2025_03_25_054843_create_master_records_table', 2),
(10, '2025_03_25_055516_create_master_references_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sowing_operations`
--

CREATE TABLE `sowing_operations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `plot_id` bigint(20) UNSIGNED NOT NULL,
  `seed_id` bigint(20) UNSIGNED NOT NULL,
  `sowing_date` date NOT NULL,
  `seed_rate` decimal(10,2) NOT NULL,
  `sowing_type` varchar(255) NOT NULL,
  `sowing_source` varchar(255) NOT NULL,
  `row_to_row_distance` decimal(10,2) NOT NULL,
  `sowing_depth` decimal(10,2) NOT NULL,
  `manpower_count` int(11) NOT NULL,
  `time_duration` varchar(255) NOT NULL,
  `major_maintenance` text DEFAULT NULL,
  `maintenance_manpower` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'admin',
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin@gmail.com', NULL, '$2y$10$vIGXsk0P4oLpfKq0izwkIeDssX1DWkYUGCe1lK6qhnsRPaxLcQhRK', '1', NULL, '2025-03-22 05:12:58', '2025-03-22 05:12:58');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `crop_protections`
--
ALTER TABLE `crop_protections`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `fertilizer_applications`
--
ALTER TABLE `fertilizer_applications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `growth_monitorings`
--
ALTER TABLE `growth_monitorings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `harvestings`
--
ALTER TABLE `harvestings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `irrigation_records`
--
ALTER TABLE `irrigation_records`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `land_preparations`
--
ALTER TABLE `land_preparations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_fertilizer`
--
ALTER TABLE `master_fertilizer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_land`
--
ALTER TABLE `master_land`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_machine`
--
ALTER TABLE `master_machine`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_records`
--
ALTER TABLE `master_records`
  ADD PRIMARY KEY (`id`),
  ADD KEY `master_records_type_record_id_index` (`type`,`record_id`);

--
-- Indexes for table `master_references`
--
ALTER TABLE `master_references`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_seed`
--
ALTER TABLE `master_seed`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `sowing_operations`
--
ALTER TABLE `sowing_operations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `crop_protections`
--
ALTER TABLE `crop_protections`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fertilizer_applications`
--
ALTER TABLE `fertilizer_applications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `growth_monitorings`
--
ALTER TABLE `growth_monitorings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `harvestings`
--
ALTER TABLE `harvestings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `irrigation_records`
--
ALTER TABLE `irrigation_records`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `land_preparations`
--
ALTER TABLE `land_preparations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `master_fertilizer`
--
ALTER TABLE `master_fertilizer`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `master_land`
--
ALTER TABLE `master_land`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `master_machine`
--
ALTER TABLE `master_machine`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `master_records`
--
ALTER TABLE `master_records`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `master_references`
--
ALTER TABLE `master_references`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `master_seed`
--
ALTER TABLE `master_seed`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sowing_operations`
--
ALTER TABLE `sowing_operations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
